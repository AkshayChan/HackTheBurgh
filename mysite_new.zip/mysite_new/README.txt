To run website:

Go to mysite folder and run:

python manage.py runserver

Url is 127..../.../ and url is /cv/upload and /cv/game/face2/

To run image processing on a singular image:

python scan.py --image images/face2.jpg
